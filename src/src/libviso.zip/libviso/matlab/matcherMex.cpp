/*
Copyright 2010. All rights reserved.
Institute of Measurement and Control Systems
Karlsruhe Institute of Technology, Germany

This file is part of libviso.
Authors: Bernd Kitt, Andreas Geiger

libviso is free software; you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or any later version.

libviso is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
libviso; if not, write to the Free Software Foundation, Inc., 51 Franklin
Street, Fifth Floor, Boston, MA 02110-1301, USA 
*/

#include "mex.h"
#include <iostream>
#include <string.h>
#include "matcher.h"

using namespace std;

static Matcher *M;

void mexFunction (int nlhs,mxArray *plhs[],int nrhs,const mxArray *prhs[]) {

  // read command
  char command[128];
  mxGetString(prhs[0],command,128);

  // init
  if (!strcmp(command,"init")) {
    
    // check arguments
    if (nrhs!=0+1 && nrhs!=10+1)
      mexErrMsgTxt("0 or 10 inputs required (param_nms_n,param_nms_tau,param_sobel_kernel,param_match_binsize,param_match_radius,param_match_disp_tolerance,param_match_uniqueness,param_outlier_binsize,param_outlier_disp_tolerance,param_outlier_flow_tolerance).");
    
    // use standard parameters
    if (nrhs==0+1) {
      M = new Matcher();

    // read parameters
    } else {
      for (int32_t i=1; i<=10; i++) {
        if (i==7) {
          if (!mxIsDouble(prhs[i]) || mxGetM(prhs[i])*mxGetN(prhs[i])!=1)
            mexErrMsgTxt("Input param_match_uniqueness must be a double scalars.");
        } else {
          if (!mxIsInt32(prhs[i]) || mxGetM(prhs[i])*mxGetN(prhs[i])!=1)
            mexErrMsgTxt("All inputs except param_match_uniqueness must be a int32_t scalars.");
        }
      }
      M = new Matcher(  *((int32_t*)mxGetPr(prhs[ 1])),
                        *((int32_t*)mxGetPr(prhs[ 2])),
                        *((int32_t*)mxGetPr(prhs[ 3])),
                        *((int32_t*)mxGetPr(prhs[ 4])),
                        *((int32_t*)mxGetPr(prhs[ 5])),
                        *((int32_t*)mxGetPr(prhs[ 6])),
                        *(( double*)mxGetPr(prhs[ 7])),
                        *((int32_t*)mxGetPr(prhs[ 8])),
                        *((int32_t*)mxGetPr(prhs[ 9])),
                        *((int32_t*)mxGetPr(prhs[10]))  );
    }

  // close
  } else if (!strcmp(command,"close")) {
    delete M;
    
  // push back stereo image pair
  } else if (!strcmp(command,"push")) {
    
    // check arguments
    if (nrhs!=1+2)
      mexErrMsgTxt("2 inputs required (I1=left image,I2=right image).");
    if (!mxIsInt16(prhs[1]) || mxGetNumberOfDimensions(prhs[1])!=2)
      mexErrMsgTxt("Input I1 (left image) must be a int16_t matrix.");
    if (!mxIsInt16(prhs[2]) || mxGetNumberOfDimensions(prhs[2])!=2)
      mexErrMsgTxt("Input I2 (right image) must be a int16_t matrix.");
    
    // get pointers to input data
    int16_t* I1 = (int16_t*)mxGetPr(prhs[1]);
    int16_t* I2 = (int16_t*)mxGetPr(prhs[2]);
    const int32_t *dims1 = mxGetDimensions(prhs[1]);
    const int32_t *dims2 = mxGetDimensions(prhs[2]);
    
    // check image size
    if (dims1[0]!=dims2[0] || dims1[1]!=dims2[1])
      mexErrMsgTxt("Input I1 and I2 must be images of same size.");

    // compute features and put them to ring buffer
    M->computeFeaturesFromImagePair(I1,I2,dims1);

  // match features
  } else if (!strcmp(command,"match")) {
    
    // check arguments
    if (nrhs!=1+3)
      mexErrMsgTxt("3 inputs required (max_features,bucket_width,bucket_height).");
    if(nlhs!=1)
      mexErrMsgTxt("One output required (p_matched).");
    if (!mxIsInt32(prhs[1]) || mxGetM(prhs[1])*mxGetN(prhs[1])!=1)
      mexErrMsgTxt("Input max_features int32_t scalar.");
    if (!mxIsDouble(prhs[2]) || mxGetM(prhs[2])*mxGetN(prhs[2])!=1)
      mexErrMsgTxt("Input bucket_width double scalar.");
    if (!mxIsDouble(prhs[3]) || mxGetM(prhs[3])*mxGetN(prhs[3])!=1)
      mexErrMsgTxt("Input bucket_height double scalar.");
    
    // get pointers to input data
    int32_t max_features  = *((int32_t*)mxGetPr(prhs[1]));
    double  bucket_width  =  *((double*)mxGetPr(prhs[2]));
    double  bucket_height =  *((double*)mxGetPr(prhs[3]));
    
    // do matching
    M->matchFeatures();
    
    // remove closeby features via bucketing
    M->bucketFeatures(max_features,bucket_width,bucket_height);
    
    // create output matrix with matches
    const int32_t p_matched_dims[] = {8,M->getMatches()->size()};
    plhs[0] = mxCreateNumericArray(2,p_matched_dims,mxSINGLE_CLASS,mxREAL);
    float* p_matched_mex = (float*)mxGetPr(plhs[0]);

    // copy matches to mex array
    int32_t k=0;
    for (vector<Matcher::p_match>::iterator it=M->getMatches()->begin(); it!=M->getMatches()->end(); it++) {
      *(p_matched_mex+k++) = it->u1p;
      *(p_matched_mex+k++) = it->v1p;
      *(p_matched_mex+k++) = it->u2p;
      *(p_matched_mex+k++) = it->v2p;
      *(p_matched_mex+k++) = it->u1c;
      *(p_matched_mex+k++) = it->v1c;
      *(p_matched_mex+k++) = it->u2c;
      *(p_matched_mex+k++) = it->v2c;
    }

  // unknown command
  } else {
    mexPrintf("Unknown command: %s\n",command);
  }
}
