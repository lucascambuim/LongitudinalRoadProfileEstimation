% Copyright 2010. All rights reserved.
% Institute of Measurement and Control Systems
% Karlsruhe Institute of Technology, Germany

% This file is part of libviso.
% Authors: Bernd Kitt, Andreas Geiger

% libviso is free software; you can redistribute it and/or modify it under the
% terms of the GNU General Public License as published by the Free Software
% Foundation; either version 2 of the License, or any later version.

% libviso is distributed in the hope that it will be useful, but WITHOUT ANY
% WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
% PARTICULAR PURPOSE. See the GNU General Public License for more details.

% You should have received a copy of the GNU General Public License along with
% libviso; if not, write to the Free Software Foundation, Inc., 51 Franklin
% Street, Fifth Floor, Boston, MA 02110-1301, USA 

dbclear all;

%%%%%%%%%%%%% MODIFY THIS SECTION %%%%%%%%%%%%%
% libcvm (windows configuration with static cvm)
%libcvm_inc  = '-I/Users/geiger/cvmlib/cvm/src';
%libcvm_lib  = '/Users/geiger/cvmlib/lib/cvm_ia32.lib';

% libcvm (linux configuration with dynamic cvm)
libcvm_inc  = '-I/opt/cvmlib.5.7/cvm/src';
libcvm_lib  = '-L/opt/cvmlib.5.7/lib64 -lcvm_em64t';
%%%%%%%%%%%%% MODIFY THIS SECTION %%%%%%%%%%%%%

% libviso
libviso_inc = '-I../src';

% compile matlab wrappers
disp('Building wrappers ...');
mex('matcherMex.cpp','../src/matcher.cpp','../src/triangle.cpp',libviso_inc,'CXXFLAGS=-msse2 -fPIC');
mex('visualOdometryMex.cpp','../src/visualOdometry.cpp','../src/trifocalTensor.cpp','../src/fundamentalMatrix.cpp',libviso_inc,libcvm_inc,libcvm_lib);
disp('...done!');
